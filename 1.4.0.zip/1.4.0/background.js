var get_title = document.getElementsByTagName('title')[0];
var get_url = location.href;
